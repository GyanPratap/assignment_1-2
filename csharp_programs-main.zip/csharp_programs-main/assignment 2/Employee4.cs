﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsharpPrograms
{
    internal partial class Employee2
    {
        /*static void Main(string[] args)
        {
            Employee2 obj4 = new Employee2();
            obj4.read("Akash singh", "akashsisodiya666@gmail.com", +918171078563);
            obj4.read(50000, 20000, 15000);
            obj4.display();
        }*/
    }
}
