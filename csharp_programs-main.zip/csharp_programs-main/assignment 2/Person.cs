﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsharpPrograms
{
    
    internal partial class Person
    {
        /*static void Main(string[] args) {
            Person obj3 = new Person();
            obj3.read("Akash", "singh");
            obj3.display();
        }*/
    }
}
