﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsharpPrograms
{
    internal abstract class Animal
    {
        abstract string name; 
        static void Main(string[] args)
        {

        }
    }
}
