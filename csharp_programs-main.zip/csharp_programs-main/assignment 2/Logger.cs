﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsharpPrograms
{
    internal static class Logger
    {
        static void LogMessage()
        {
            Console.WriteLine("Mission successfull");
        }
        /*static void Main(string[] args)
        {
            Logger.LogMessage();
        }*/
    }
}
